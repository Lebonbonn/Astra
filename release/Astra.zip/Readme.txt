Welcome to Astra.

Open Loader.exe after opening Vortex to inject

Resize window after injecting to hook renderer

Press Insert to open the internal editor
Press F9 to open the developer console

Make sure you injected before going in a game to decompile scripts

Try using saveinstance() to save any game and open it in Vortex studio (saved to the Workspace folder)

Scripts like Infinite Yield, vUNC test, UnnamedESP, and Dex are available in the Scripts tab

See latest downloads at https://getastra.win/download/vortex
See full Vortex documentation at https://getastra.win/docs/vortex

Have fun!