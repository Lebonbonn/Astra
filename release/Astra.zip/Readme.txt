Welcome to Astra.

Open Loader.exe after opening Vortex to inject

Resize window after injecting to hook renderer

Press Insert to open the internal editor
Press F9 to open the developer console

Make sure you're injected before going in a game to decompile scripts

Try using saveinstance() to save any game and open it in Vortex studio (saved to the Workspace folder)

Scripts like Infinite Yield, UnnamedESP, Dex, and more are available in the Scripts tab
You can access those and add more scripts in the Scripts folder

See latest downloads at https://getastra.win/download/vortex
See full Vortex documentation at https://getastra.win/docs/vortex

Make sure to join our Discord to chat, report any bugs, and see announcements
https://discord.gg/TRhs2pjqhJ

Have fun!